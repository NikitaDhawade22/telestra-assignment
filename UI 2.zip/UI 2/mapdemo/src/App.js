import React, {Component} from 'react';
import Main from './components/Main'
import './App.css';
import IndiaMap from './resources/india.jpg';
import PuneMap from './resources/pune.jpg';
import { Button, Form, Spinner}  from 'react-bootstrap';


class App extends Component{
  constructor(props){
    super(props);
    this.state = {
      loader: false,
      image2: false
    }
    this.handleLoader = this.handleLoader.bind(this);
    this.handleImage = this.handleImage.bind(this);
 }

 handleLoader = (loader) => {
   this.setState({loader})
 }

 handleImage = (image2) => {
  this.setState({image2})
}


render(){
  return (
    <div className="App">
      <Form className='box'>        
        {this.state.loader ? <div>
          <Spinner animation="border" role="status">
          <span className="sr-only">Loading...</span>
        </Spinner></div>: this.state.image2 ?
        <img src={PuneMap}  alt="Image1" width='350'/>:
        <img src={IndiaMap}  alt="Image2" width='350'/>}
        <Main handleLoader={this.handleLoader.bind(this.state.loader)} handleImage={this.handleImage.bind(this.state.image2)}/>
        <br></br>
        <Button variant="success">Submit</Button>
      </Form>
    </div>
  )}
}

export default App;












