import React, { Component } from 'react';
import Main from './components/Main'
import './App.css';
import IndiaMap from './resources/india.jpg';
import PuneMap from './resources/pune.jpg';
import { Button, Form, Spinner } from 'react-bootstrap';

const divStyle = {
  textAlign: 'center',
  margin: '20px',
  color: 'green'
}
class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loader: false,
      image2: false,
      selectedHotelName: '',
      showMessage: false
    }
    this.handleLoader = this.handleLoader.bind(this);
    this.handleImage = this.handleImage.bind(this);
  }

  handleLoader = (loader) => {
    this.setState({ loader })
  }

  handleImage = (image2) => {
    this.setState({ image2 })
  }

  handleClick = () => {
    this.setState({ showMessage: true })

  }

  handleHotelName = (selectedHotelName) => {
    this.setState({ selectedHotelName })
  }


  render() {
    return (
      <div>
        <header style={divStyle}>
          <h3>Google Map</h3>
        </header>
        <Form className='box'>
          {this.state.loader ? <div>
            <Spinner animation="border" role="status">
              <span className="sr-only">Loading...</span>
            </Spinner></div> : this.state.image2 ?
              <img src={PuneMap} alt="Image1" width='350' /> :
              <img src={IndiaMap} alt="Image2" width='350' />}
          <Main handleLoader={this.handleLoader.bind(this.state.loader)} handleHotelName={this.handleHotelName} handleImage={this.handleImage.bind(this.state.image2)} />
          <br></br>
          <Button variant="success" onClick={this.handleClick}>Submit</Button>
          {this.state.showMessage ? <h1>Welcome to {this.state.selectedHotelName} Hotel</h1> : ""}
        </Form>
      </div>
    )
  }
}

export default App;



