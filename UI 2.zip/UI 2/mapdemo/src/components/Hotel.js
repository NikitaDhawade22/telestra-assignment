import React, { Component } from 'react';

export default class Hotel extends Component {

  handleHotelList = (event) => {
    this.props.handleLoader(false);
    this.props.handleImage(true);
    this.props.handleHotelName(event.target.value)
  }

  render() {
    let hotelNames = [];
    const { hotels, selectedCoordinates, coordinates } = this.props;
    for (let [key, value] of Object.entries(hotels)) {
      const valueOfXY = Object.values(coordinates)[selectedCoordinates];

      if (valueOfXY && value) {
        if (value['x'] === valueOfXY['x'] && value['y'] === valueOfXY['y']) {
          hotelNames.push(<option key={key} >
            {key}
          </option>)
        }
      }
    }
    return (
      <div>

        <select onChange={this.handleHotelList}>
          <option>Hotel </option>
          {hotelNames}
        </select>
      </div>
    );
  }

}