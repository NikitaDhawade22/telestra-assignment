import React, {Component} from 'react';
  
  export default class Hotel extends Component {  

    handleHotelList=()=>{
      this.props.handleLoader(false);
      this.props.handleImage(true);
    }

    render(){ 
      let hotelNames = [];
      for (let [key, value] of Object.entries(this.props.hotel)) {
        const valueOfXY = Object.values(this.props.coordinates)[this.props.selectedCoordinates];
        if(value['x']===valueOfXY['x'] && value['y']=== valueOfXY['y']){
          hotelNames.push(<option key={key}>
            {key}
          </option>)
        }
        
      }
      return (
        <div>

           <select onChange={this.handleHotelList}>
            <option>Hotel </option>
              {hotelNames}
           </select>
         </div>
       );
    }
    

}