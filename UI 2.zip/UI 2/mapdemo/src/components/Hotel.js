import React, {Component} from 'react';
  
  export default class Hotel extends Component {  

    handleDropDown2=()=>{
      this.props.handleLoader(false);
      this.props.handleImage(true);
    }

    render(){ 
      let array = [];
      for (let [key, value] of Object.entries(this.props.hotel)) {
        const valueOfXY = Object.values(this.props.coordinates)[this.props.selectedCoordinates];
        if(value['x']===valueOfXY['x'] && value['y']=== valueOfXY['y']){
          array.push(<option key={key}>
            {key}
          </option>)
        }
        
      }
      return (
        <div>

           <select onChange={this.handleDropDown2}>
            <option>Hotel </option>
              {array}
           </select>
         </div>
       );
    }
    

}