import React, { Component } from 'react';
import Hotel from './Hotel';
import axios from 'axios';

export default class Coordinates extends Component {

  constructor(props) {
    super(props);

    this.state = {
      coordinates: [],
      selectedCoordinates: '',
      hotels: [],
    };

    this.handleCoordinates = this.handleCoordinates.bind(this);
  }

  componentDidMount() {
    axios.all([
      axios.get('http://localhost:8080/map/api1'),
      axios.get('http://localhost:8080/map/api2')
    ])
      .then(axios.spread((obj1, obj2) => {
        this.setState({
          coordinates: obj1.data,
          hotels: obj2.data
        })
      }));
  }

  handleCoordinates(e) {
    this.props.handleLoader(true);
    this.setState({
      selectedCoordinates: e.target.value // select type coordinate
    })
  }

  render() {
    let selectType = Object.values(this.state.coordinates).map((element, index) => {
      const valuesOfCoordinates = JSON.stringify(index)
      return (
        <option key={valuesOfCoordinates}>
          {valuesOfCoordinates}
        </option>

      )
    }
    )

    return (
      <div>
        <br></br>
        <select onChange={this.handleCoordinates}>
          <option>Select Type </option>
          {selectType}
        </select>
        <div>
          <br></br>
          <Hotel hotels={this.state.hotels} selectedCoordinates={this.state.selectedCoordinates} coordinates={this.state.coordinates} handleLoader={this.props.handleLoader} handleImage={this.props.handleImage} handleHotelName={this.props.handleHotelName} />
        </div>
      </div>
    );
  }
}