import React, { Component } from 'react';
import Hotel from './Hotel';
import axios from 'axios';

export default class Coordinates extends Component {

  constructor(props) {
    super(props);

    this.state = {
      coordinates: [],
      selectedCoordinates: '',
      hotels: [],
    };
    this.handleDropDown1=this.handleDropDown1.bind(this);
  }

  componentDidMount() {
    axios.get("http://localhost:8080/map/api1") //Fetch api1
      .then(response => {
        this.setState({ coordinates: response.data })
      }, error => {
        console.log(error);
      })
  }

  handleDropDown1(e){
    this.props.handleLoader(true);
    // this.props.handleImage(true);
    this.setState({
      selectedCoordinates: e.target.value // select type coordinate
    })
    axios.get("http://localhost:8080/map/api2") //fetch api2
      .then(response => { 
        this.setState({hotels:response.data})
      }, error => {
        console.log(error);
      })
  }

  exactValueOfSelectedCoordinate =()=>{
 const finalData = Object.values(this.state.coordinates).filter((element,index)=>this.state.selectedCoordinates &&
  this.state.selectedCoordinates===JSON.stringify(index))
return finalData;
  }

  render() {
    let selectType = Object.values(this.state.coordinates).map((element, index) => {
      const ee = JSON.stringify(index)
      return (
        <option key={ee}>
          {ee}
        </option>

      )
    }
    )

    return (
      <div>

        <br></br>
        <select onChange={this.handleDropDown1}>
          <option>Select Type </option>

          {selectType}
        </select>

        <div>
          <br></br>
          <Hotel hotel={this.state.hotels} selectedCoordinates={this.state.selectedCoordinates} coordinates={this.state.coordinates} handleLoader={this.props.handleLoader} handleImage={this.props.handleImage} />
        </div>


      </div>
    );
  }



}