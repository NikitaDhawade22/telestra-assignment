var express = require('express');
var router = express.Router();
const API1= require('../resources/API1.json')

/* GET home page. */
router.get('/', function(req, res, next) {
  res.send('index', { title: API1 });
});

module.exports = router;
