var express = require('express');
var app = express();
var cors = require('cors')
app.use(cors()) 

var API1 = require('../resources/API1.json')
var API2 = require('../resources/API2.json')

// router.get('/', function(req, res, next) {
//     res.send('API is working properly');
// });

app.get('/map/api1',(req,res)=>res.send(JSON.stringify(API1)))
app.get('/map/api2',(req,res)=>res.send(JSON.stringify(API2)))


app.listen(8080)

module.exports = app;